import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {	
	def headers = message.getHeaders();	
	def logger = message.getProperty("logger");
	
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def Jobs_URL = message.getProperty("Jobs_URL");
	def ApiKey = headers.get("ApiKey");
	def Authorization = headers.get("Authorization");
	
	String prop = Jobs_URL + "\n" + ApiKey + "\n" + Authorization + "\n";
	
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("links", prop, "text/plain");
	};
	
	return message;
}
