import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {	
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	def logger = message.getProperty("logger");
	def jobID = message.getProperty("jobID");
	
	//append hashmap with new property collected fromfor jobID
	HashMap<Integer, String> propertiesMap = headers.get("propertiesMap");
	propertiesMap.put("jobID", jobID);
	
	String output = "";
	String body = "";
	for (Map.Entry <String, String > mapObject: propertiesMap.entrySet()) {
		body = body + mapObject.getKey() + "^^" + mapObject.getValue() + "~";
		output = output + mapObject.getKey() + "^^" + mapObject.getValue() + "\n";
	};
	
	message.setBody(body);	
		
	if(messageLog != null && logger.equalsIgnoreCase("true")){	    
		messageLog.addAttachmentAsString("going_to_step2_body", body, "text/plain");
		//messageLog.addAttachmentAsString("nextPageBody_Properties", output, "text/plain");
	};	
	return message;
}