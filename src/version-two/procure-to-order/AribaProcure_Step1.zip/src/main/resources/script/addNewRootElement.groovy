import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.io.File
import java.util.HashMap;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.DateFormat;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	// add additional root node for conveninence of adding, removing elements at later stage
	  def root = new XmlSlurper().parseText(body); 	  
	  def markup = new groovy.xml.StreamingMarkupBuilder();	  
	  def newXml = markup.bind { rootNode { mkp.yield root } };
	  String newBody = groovy.xml.XmlUtil.serialize(newXml);
	
	message.setBody(newBody);
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("submitJob_Payload", newBody, "text/xml");
	};
	return message;
}