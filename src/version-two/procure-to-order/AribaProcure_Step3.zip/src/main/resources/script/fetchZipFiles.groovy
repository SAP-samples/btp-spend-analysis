import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;

def Message processData(Message message) {
	def logger = message.getProperty("logger");	
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def root = new XmlParser().parseText(body);
	String hasMoreRecords = "False";
	HashMap<String, String> filenamesMap = new HashMap<String, String>();
	
	String filenames = root.StatementName_response.response_1.row.JOB_FILE_NAME.text();		
		
		String[] tokens = filenames.split("@");
		for (int i=0; i < tokens.length; i++) {
			String tokenValue = tokens[i];
			if(tokenValue.contains(".zip")) {
				String kk = i+"";
				filenamesMap.put(kk, tokenValue);				
			};
		};
		
		if(filenamesMap.size() > 0) {
			hasMoreRecords = "True";
		};
		
		message.setHeader("filenamesMap", filenamesMap);
		message.setProperty("hasMoreRecords",hasMoreRecords);		
				
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		messageLog.addAttachmentAsString("filenames", body, "text/plain");
	};
	return message;
}