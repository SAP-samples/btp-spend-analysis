import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def jobStatus_URL = message.getProperty("jobStatus_URL");
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	def nextBody = message.getProperty("nextBody");	
	
	String hasMoreRecords = "False";
	HashMap<String, String> filenamesMap = headers.get("filenamesMap");
	String oneZipFileLink = "";
	
	String status = "Before Trigger - LeftOver FileCount = " + filenamesMap.size() + "\n";
	
	int i = 0;
	for (Map.Entry <Integer, String > mapObject: filenamesMap.entrySet()) {
		if(i < 1) {
			String val = mapObject.getValue();
			oneZipFileLink = jobStatus_URL + "/" + val;
			filenamesMap.remove(mapObject.getKey());
			break;
		};
	};
	//prepare body to carry forward all the properties to next step
	nextBody = nextBody + "oneZipFileLink" + "^^" + oneZipFileLink + "~";
	
	status = status + "Current Processing File = " + oneZipFileLink + "\n";
	status = status + "After Trigger - LeftOver FileCount = " + filenamesMap.size() + "\n";
		
	if(filenamesMap.size() > 0) {
		hasMoreRecords = "True";
	};
	// Property "hasMoreRecords" - does need to go to next step since it is local current step
	message.setProperty("hasMoreRecords",hasMoreRecords);	

	
	message.setBody(nextBody);
				
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		messageLog.addAttachmentAsString("Files_Loading_status", status, "text/plain");
	};
	return message;
}