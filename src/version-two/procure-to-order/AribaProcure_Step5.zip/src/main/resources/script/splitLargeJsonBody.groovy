import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.json.JsonOutput;
import groovy.json.JsonSlurper;
import java.util.Random;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	HashMap<String, String> fiftyKrecords = new HashMap<String, String>();
	String hasMoreRecords = "";	
	final List<Map> bigJsonPayload = new JsonSlurper().parseText(body) as List<Map>;
	
	def Split_Chunk_count = message.getProperty("Split_Chunk_count");
	int count = Integer.parseInt(Split_Chunk_count);
	
	bigJsonPayload.collate(count).each { smallChunk ->
		final String chunkedContent = JsonOutput.toJson(smallChunk);
		Random rnd = new Random();
		String key = rnd.nextInt(999999) + "";
		fiftyKrecords.put(key, chunkedContent);
		//messageLog.addAttachmentAsString("zipFileContent", chunkedContent, "text/plain");
	};
	
	if(bigJsonPayload.size() > 0) {
		hasMoreRecords = "True";
	}else {
		hasMoreRecords = "False";
	};
	message.setProperty("hasMoreRecords",hasMoreRecords);	
	message.setHeader("fiftyKrecords",fiftyKrecords);
	
	message.setBody("");	//clear memory for better performance
	bigJsonPayload.clear();	// reset memory
		
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("10KChunk", chunkedContent, "text/plain");
	};
	
	return message;
}