import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.JsonSlurper;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	String newBody = "";
	
	// this script will mitigate limitations of Json-2-XML converter
	// for more details - https://launchpad.support.sap.com/#/notes/0002478282
	
	if(body != null && body.trim().length() > 0) {
	    
	    body = body.replaceAll("'",""); // remove single quote from xml values	
	    
		def appendNodes = body.substring( 1, body.length() - 1 ) ;
		appendNodes ="{\"Root\": [{\"Element\":["+appendNodes+"]}]}";
		newBody = appendNodes.toString(); 
	};
	
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("problemZipFile", newBody, "text/plain");
	}	
	message.setBody(newBody);
	return message;
}
