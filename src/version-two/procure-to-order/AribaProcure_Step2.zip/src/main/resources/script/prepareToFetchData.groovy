import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def headers = message.getHeaders();	
	HashMap<String, String> baseURLs = headers.get("baseURLs");
	String hasMoreRecords = "False";
	String fqdn = "";
	
	if(baseURLs.size() > 0) {
	    int i = 0;
		for (Map.Entry < String, String > mapObject: baseURLs.entrySet()) {
		    if(i < 1) {
    			fqdn = mapObject.getValue();
    			message.setProperty("fqdn",fqdn);
    			baseURLs.remove(mapObject.getKey());
    			i++;
		    }
		};
	};
	
	if(baseURLs.size() > 0 && fqdn.trim().length() > 5) {
		hasMoreRecords = "True";
	}else {
		hasMoreRecords = "False";
	};
	message.setProperty("hasMoreRecords",hasMoreRecords);
	message.setHeader("baseURLs",baseURLs);

	if(messageLog != null && logger.equalsIgnoreCase("true")){
		String content = "LeftOver FQDN count = " + baseURLs.size() + " , hasMoreRecords = " + hasMoreRecords;
	    messageLog.addAttachmentAsString("fqdn", fqdn, "text/plain");
	};
	return message;
}