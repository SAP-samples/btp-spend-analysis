import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();
	
	String hasMoreRecords = "";	
	HashMap<String, String> callRoster = headers.get("callRoster");
	HashMap<String, String> baseURLs = new HashMap<String, String>();
	
	if(callRoster.size() > 0) {
		int i=0;	// for each iteration, process 10 files, because each page from ariba contains 10 zipfiles 
		for (Map.Entry <String, String > mapObject: callRoster.entrySet()) {
			i++;
			String value = mapObject.getValue();
			if(i < 11) {
				String ky = i+"";
				baseURLs.put(ky, value);
			};			
		};
	};
	
	if(baseURLs.size() > 0) {
		hasMoreRecords = "True";
	}else {
		hasMoreRecords = "False";
	};
	
	message.setProperty("hasMoreRecords",hasMoreRecords);
	message.setHeader("baseURLs",baseURLs);

	if(messageLog != null && logger.equalsIgnoreCase("true")){
		String size = "Number of files to process = " + baseURLs.size();
		messageLog.addAttachmentAsString("Total_FQDN_2_Call", size, "text/plain");
	};
	return message;
}