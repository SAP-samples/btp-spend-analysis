import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.*;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def baseURL = message.getProperty("base_job_url");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	def headers = message.getHeaders();

	HashMap<String, String> callRoster = new HashMap<String, String>();
	HashMap<String, String> propertiesMap = headers.get("propertiesMap");;
	String hasMoreRecords = "False";
	
	//collect & build new roster from newly completed job
	def root = new XmlParser().parseText(body);
	String status = root.status.text();
	String jobId = root.jobId.text();
	String pageToken = root.pageToken.text();
	String viewTemplateName = root.viewTemplateName.text();
	String updatedDateFrom = root.filters.updatedDateFrom.text();
	String updatedDateTo = root.filters.updatedDateTo.text();
	
		if(status.equalsIgnoreCase("completed")) {
			for(def fNames : root.files) {
				String file = fNames.text();
				String url = jobId + "/files/" +  file;
				String counter = (callRoster.size()+1) + "";
				callRoster.put(counter, url);
			};
		};
		
		if(pageToken !=null && pageToken.length() > 3) {
			hasMoreRecords = "True";
			message.setProperty("pageToken", pageToken);
			message.setProperty("hasMoreRecords", hasMoreRecords);			
		};

	//after collecting full list of links, write it to global variable for storage
		String gv_roster = "@";
		for (Map.Entry <Integer, String > mapObject: callRoster.entrySet()) {
			String val = mapObject.getValue().toString().trim();
			gv_roster = gv_roster + val + "@";
		};
		message.setProperty("gv_roster", gv_roster);
		
		String nextBody = "";
		if(propertiesMap != null) {
			body = "";
			for (Map.Entry <String, String > mapObject: propertiesMap.entrySet()) {
				nextBody = nextBody + mapObject.getKey() + "^^" + mapObject.getValue() + "~";
			};
		};
		message.setProperty("nextBody", nextBody);
		callRoster.clear();

	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("propertiesForNextPage", properties, "text/plain");
	};
	return message;
}