import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def prop = message.getProperties();
	
	//if this is a job submit for NextPage - then body will contain PageToken. So pull it out
	def body = message.getBody(java.lang.String) as String;	
	HashMap<String, String> propertiesMap = new HashMap<String, String>();
	
	String Token_Credential = prop.get("11_Token_Credential");
	propertiesMap.put("Token_Credential", Token_Credential);

	String JDBC_Credential = prop.get("12_JDBC_Credential");
	propertiesMap.put("JDBC_Credential", JDBC_Credential);
	
	String APIKEY = prop.get("13_APIKEY");
	propertiesMap.put("APIKEY", APIKEY);
	
	//This job submit could be either for intial page job submit or nextpage results job Submit.
	// so, if nextPage submit - then supply PageToken after realm.
	String realm = prop.get("14_Realm");
	String queryParams = "";
	String pageToken = "";
	if(body !=null && body.trim().length() > 3) {
		String[] tokens = body.split("@");		
		for (int i=0; i < tokens.length; i++) {
			pageToken = tokens[i].trim();
		};
		queryParams = realm.toString().trim() + "&pageToken=" + pageToken;
	}else {
		queryParams = realm.toString().trim();
	};
	propertiesMap.put("Realm", queryParams);
	
	String ViewTemplateName = prop.get("15_ViewTemplateName");
	propertiesMap.put("ViewTemplateName", ViewTemplateName);
	
	String FromDate = prop.get("16_FromDate");
	propertiesMap.put("FromDate", FromDate);
	
	String ToDate = prop.get("17_ToDate");
	propertiesMap.put("ToDate", ToDate);
	
	String MessageMap = prop.get("18_MessageMap");
	propertiesMap.put("MessageMap", MessageMap);
	
	String SPROC_Files = prop.get("19_SPROC_Files");
	propertiesMap.put("SPROC_Files", SPROC_Files);
	
	String SPROC_Final = prop.get("20_SPROC_Final");
	propertiesMap.put("SPROC_Final", SPROC_Final);
	
	String SPROC_GET_FILE = prop.get("21_SPROC_GET_FILE");
	propertiesMap.put("SPROC_GET_FILE", SPROC_GET_FILE);
	
	String SPROC_TRN_FILE = prop.get("22_SPROC_TRN_FILE");
	propertiesMap.put("SPROC_TRN_FILE", SPROC_TRN_FILE);
	
	String GrantType = prop.get("23_GrantType");
	propertiesMap.put("GrantType", GrantType);
	
	String sleep_in_mins = prop.get("24_sleep_in_mins");
	propertiesMap.put("sleep_in_mins", sleep_in_mins);
	
	String Split_Chunk_count = prop.get("25_Split_Chunk_count");
	propertiesMap.put("Split_Chunk_count", Split_Chunk_count);
	
	String logger = prop.get("26_logger");
	propertiesMap.put("logger", logger);
	
	String Token_URL = prop.get("27_Token_URL");
	propertiesMap.put("Token_URL", Token_URL);
	
	String Jobs_URL = prop.get("28_Jobs_URL");
	propertiesMap.put("Jobs_URL", Jobs_URL);
	
	String jobStatus_URL = prop.get("29_jobStatus_URL");
	propertiesMap.put("jobStatus_URL", jobStatus_URL);
		
	message.setHeader("propertiesMap", propertiesMap);
	String output = "";
	for (Map.Entry <String, String > mapObject: propertiesMap.entrySet()) {
		message.setProperty(mapObject.getKey(), mapObject.getValue());
		output = output + mapObject.getKey() + " -::- " + mapObject.getValue() + "\n";
	};
	
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("propertiesMap", output, "text/plain");
	};
	return message;
}