import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def rootNode = new XmlSlurper().parseText(body);
	String jobID = "";
	
	for(def result : rootNode.root) {
		String status = result.status.text();
		jobID = result.jobId.text();
	};
	
	message.setProperty("jobID",jobID);
		
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("jobID", jobID, "text/plain");
	};
	return message;
}