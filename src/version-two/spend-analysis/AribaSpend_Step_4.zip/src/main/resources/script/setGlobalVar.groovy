import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def previousValue = message.getProperty("p_global_var");
	def currentValue = message.getProperty("reDirURL");	
	
	String newGlobalValue = previousValue + "^" + currentValue; 
	
	message.setProperty("newGlobalValue",newGlobalValue);

	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("itr_result", content, "text/plain");
	};
	return message;
}