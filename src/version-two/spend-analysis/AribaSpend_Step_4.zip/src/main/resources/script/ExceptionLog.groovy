import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Map;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def headers = message.getHeaders();
	def messageLog = messageLogFactory.getMessageLog(message);
	HashMap<Integer, String> propertiesMap = headers.get("propertiesMap");

	def map = message.getProperties();
	
	// get an exception java class instance
	def exception = map.get("CamelExceptionCaught");
	if (exception != null) {
		Map<String, String> hdrMap = exception.getResponseHeaders();
		
		String fqdn = "";
		for (Map.Entry<String,String> entry : hdrMap.entrySet()) {
			if(entry.getKey().equalsIgnoreCase("Location")) {
				fqdn = entry.getValue();
			};
		};
				
		if(fqdn.length() > 1)	{
			//Append FQDN to propertiesMap to carry it forward into next steps
			propertiesMap.put("FQDN", fqdn);	
		};
		
		//prepare body to carry forward all the properties to next step
		String body = "";
		for (Map.Entry <String, String > mapObject: propertiesMap.entrySet()) {
			body = body + mapObject.getKey() + "^^" + mapObject.getValue() + "~";
		};
		
		message.setBody(body);
		
		if(messageLog != null && logger.equalsIgnoreCase("true")) {
			messageLog.addAttachmentAsString("FQDN", fqdn, "text/plain");
		};
	};
	return message;
}