import com.sap.gateway.ip.core.customdev.util.Message;
import groovy.xml.XmlUtil;
import java.io.File
import java.util.HashMap;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.text.DateFormat;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def jobID = message.getProperty("p_jobID");
	def fileName = message.getProperty("p_filename");
	String baseURL = "https://openapi.ariba.com/api/analytics-reporting-jobresult/v1/prod/jobs/";
	String dowloadUrl = baseURL + jobID.toString() + "/files/" + fileName.toString();
	
	//String dowloadUrl = "https://s1.ariba.com/Sourcing/reportingapi/v2/reports/jobresults/jobs/c8958f1a-35be-45cd-bbb8-1f3be4995e751637293200723/files/Fkw5ufz5i.zip/_c_/C65?realm=cloudprospects-t&token=M2JSY05UNE1TRDRhVFFHdS9MaHg0SlJtVmp5c3R0NFJEcGZaWDI1T041c2JTdkJYTmZCWHFFYUVMUUNCOTd3N1ZBT1lKTEpIQlpJU25EekVJZG5nZ1l3bGhheW1QN1py&requestId=SE4yNkt1Y3BqdGxsZ3NTdzFLcDQrNjdmdlBCVWUyNnhrazNHZ3NCMzNhbDNRUUlYTWlwKzNSME0xbGVBdERIVw";
	
	//String dowloadUrl = "https://s1.ariba.com/Sourcing/reportingapi/v2/reports/jobresults/jobs/c2218b71-a16b-40a9-b3a4-c89cfd74056d1637335440514/files/Fkw6jg7l6.zip/_c_/C65?realm=cloudprospects-t&token=NDR5V3Avb0Q1UVpNZGZJVnA1blNWYWswMzBMK2k0b3l6K2ZCNkNQQjI2eklzanI2WUJQaUVYekltSmhrTHdxTFdsWGs3eWV4ZWd6czlMdVMxNlZ1R0c1OWRnYklIaC8z&requestId=QXhmTVVXVjdKMmoyMDNjWjRxT1I0eFlTb2ZlaWtRT0tGMUQxQ1o3TE5yQkNmcUtyTEd2YWVkN09BbWpRbEFxWg";
	
	message.setProperty("fileDownloadUrl", dowloadUrl);

	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("fileDownloadUrl", dowloadUrl, "text/plain");
	};
	return message;
}