import com.sap.gateway.ip.core.customdev.util.Message;


def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	if(body != null && body.trim().length() > 0) {		
		//strip out initial xml defnition part like - <?xml version=1.0 encoding=UTF-8?>
		int i = body.indexOf(">") + 1;
		body = body.substring(i, body.length());
	};
	
	message.setBody(body);
			
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("XML_After_Map", body, "text/xml");
	};
	
	return message;
}