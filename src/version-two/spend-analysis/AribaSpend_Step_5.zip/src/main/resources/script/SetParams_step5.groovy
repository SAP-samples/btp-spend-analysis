import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	String body = message.getBody();

	HashMap<String, String> propertiesMap = new HashMap<String, String>();
	
	String[] rawContent = body.split("~");
	for(String keyPair :rawContent ) {
		int carat =  keyPair.indexOf("^^");
		String key = keyPair.substring(0, carat);
		
		carat = (carat + 2);
		String value = keyPair.substring(carat, keyPair.length());
		propertiesMap.put(key, value);
	};
	
	String properties = "";
	for (Map.Entry <String, String > mapObject: propertiesMap.entrySet()) {
		message.setProperty(mapObject.getKey(), mapObject.getValue());
		properties = properties + mapObject.getKey() + " -::- " + mapObject.getValue() + "\n";
	};
	
	message.setHeader("propertiesMap", propertiesMap);
	
	//messageLog.addAttachmentAsString("properties", body, "text/plain");
	return message;
}