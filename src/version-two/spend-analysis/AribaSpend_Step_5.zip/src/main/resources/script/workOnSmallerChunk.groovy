import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	def headers = message.getHeaders();	
	HashMap<String, String> fiftyKrecords = headers.get("fiftyKrecords");
	String hasMoreRecords = "False";
	
	if(fiftyKrecords != null && fiftyKrecords.size() > 0) {
		for (Map.Entry < String, String > mapObject: fiftyKrecords.entrySet()) {
			String smallerChunkJson = mapObject.getValue();
			message.setProperty("smallerChunkJson",smallerChunkJson);
			fiftyKrecords.remove(mapObject.getKey());
			break;
		};
	};
	
	if(fiftyKrecords != null && fiftyKrecords.size() > 0) {
		hasMoreRecords = "True";
	}else {
		hasMoreRecords = "False";
		if(fiftyKrecords != null)
			fiftyKrecords.clear();
	};
	message.setProperty("hasMoreRecords",hasMoreRecords);
	message.setHeader("fiftyKrecords",fiftyKrecords);

	if(messageLog != null && logger.equalsIgnoreCase("true")){
		String log = "";
		if(fiftyKrecords !=null) {
			log = fiftyKrecords.size();
		} else log = "0";
		String content = "LeftOver JsonChunks count = " + log + " , hasMoreRecords = " + hasMoreRecords;
		//messageLog.addAttachmentAsString("itr_result", content, "text/plain");
	};
	return message;
}