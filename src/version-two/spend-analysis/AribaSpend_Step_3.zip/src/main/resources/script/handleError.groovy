import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
	def logger = message.getProperty("logger");
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		messageLog.addAttachmentAsString("call_result", body, "text/plain");
	};
	
	return message;
}
