import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.Map;

def Message processData(Message message) {
	def messageLog = messageLogFactory.getMessageLog(message);
	def logger = message.getProperty("logger");
	def jobStatus_URL = message.getProperty("jobStatus_URL");
	def jobID = message.getProperty("jobID");
	
	String nextURL = jobStatus_URL.toString() .trim() +"/" + jobID.trim() + "?";
	message.setProperty("jobStatusURL",nextURL);
	
	def pause = message.getProperty("sleep_in_mins");
	int milliSeconds = Integer.parseInt(pause) * 60 * 1000;
	sleep(milliSeconds);	
	
	if(messageLog != null && logger.equalsIgnoreCase("true")){
		//messageLog.addAttachmentAsString("jobStatusURL", nextURL, "text/plain");
	};
	return message;
}
